<?php

/*** This this the name of the folder the files reside in. Default is /uni  ALWAYS BEGINS WITH '/' */
define('folder_name', '/Project');

/*** MySQL database host.*/
define('db_host', 'localhost');

/*** MySQL database username */
define('db_username', 'root');

/*** MySQL database password */
define('db_password', '');

/*** MySQL database name. */
define('db_name', 'project');


