<script type="text/javascript">
	window.location = 'view-modules.php';	
</script>