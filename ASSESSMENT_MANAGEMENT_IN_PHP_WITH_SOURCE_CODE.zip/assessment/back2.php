<script type="text/javascript">
	window.location = 'students-view.php';	
</script>