<script type="text/javascript">
	window.location = 'view-users.php';	
</script>